package com.daw.daw_task;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DawTaskApplicationTests {

	@Test
	void contextLoads() {
	}

}
