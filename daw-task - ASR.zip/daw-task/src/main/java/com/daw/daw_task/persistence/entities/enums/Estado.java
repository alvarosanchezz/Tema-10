package com.daw.daw_task.persistence.entities.enums;

public enum Estado {
	PENDIENTE, EN_PROGRESO, COMPLETADA
}
